<div id="msg-box">
    <div>請聯繫管理員確定密碼</div>
    <div id="center-btn">確定</div>
</div>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/github/new_sea/resources/views/components/box-message.blade.php ENDPATH**/ ?>