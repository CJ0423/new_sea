<?php $__env->startSection('title'); ?>
    A-1
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/front/a1.scss']); ?>
    <style>
        <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            .a1-<?php echo e($index + 1); ?> {
                background-image: url("<?php echo e(asset('storage/' . $item->img_pc_url)); ?>");
            }

            @media (max-width:767px) {
                .a1-<?php echo e($index + 1); ?> {
                    background-image: url("<?php echo e(asset('storage/' . $item->img_pad_url)); ?>");
                }

            }
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('version'); ?>
    <div class="container-pc">
        <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div data-aos="custom-animation-up" class="a<?php echo e($index + 1); ?> <?php echo e($item->img_size_pad); ?> ">
                <figure class="main-img a1-<?php echo e($index + 1); ?>">
                    <figcaption>
                        <h2><?php echo e($item->title); ?></h2>
                        <h3><?php echo e($item->subtitle); ?></h3>
                        <a href="<?php echo e($item->button_link); ?>" class="buy-now-button"><?php echo e($item->button_name); ?></a>
                    </figcaption>
                </figure>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div style="clear: both"></div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/github/new_sea/resources/views/front/A1.blade.php ENDPATH**/ ?>