<?php $__env->startSection('title'); ?>
    後端管理-Banner管理
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/banner.scss']); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('cut'); ?>
    <!-- 以下分割 -->
    <div class="size16">Banner列表</div>
    <div class="border border-0 card">
        <!-- 提示訊息 -->
        

        <div class="border-bottom frame-2">
            <div class="size12"><input type="button" class="border border-0 border-bottom border-success-subtle input-all"
                    value="全部"><input type="button" class="border border-0 border-bottom border-success-subtle input-down"
                    value="已下架"></div>
            <a href=<?php echo e(route('BannerEstabilsh')); ?> class="button-establish">
                <img class="icon-outline-plus" src=<?php echo e(asset('img/icon-outline-plus-22.svg')); ?>>
                <div class="text-2">建立選單</div>
            </a>
        </div>
        <form class="my-form" action="" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="frame-3">
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">ID</th>
                            <th scope="col">Banner縮圖</th>
                            <th scope="col">主標題</th>
                            <th scope="col">顯示順序</th>
                            <th scope="col">上架/下架時間</th>
                            <th scope="col">狀態</th>
                            <th scope="col">操作</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $banner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $nowTime = \Carbon\Carbon::now();
                                // 假设 $items 包含 start_time 和 end_time
                                $start_time = \Carbon\Carbon::parse($item->start_time);
                                $end_time = \Carbon\Carbon::parse($item->end_time);

                                $isOnSale = $start_time->lte($nowTime) && $end_time->gt($nowTime);
                                $isOffSale = $end_time->lte($nowTime);
                                $isScheduledToSale = $start_time->gt($nowTime);
                            ?>


                            <tr
                                class="border-bottom
                                  <?php if($isOnSale): ?> banner-superior
                                    <?php elseif($isScheduledToSale): ?>
                                        banner-prepare
                                    <?php else: ?>
                                     banner-down <?php endif; ?>">
                                <th scope="row"><?php echo e($item->id); ?></th>
                                <td><img src='<?php echo e(asset("storage/$item->img_pc_url")); ?>' alt=""></td>
                                <td><?php echo e($item->title); ?></td>
                                <td><?php echo e($item->Rank); ?></td>
                                <td><?php echo e($item->start_time); ?><br><?php echo e($item->end_time); ?></td>
                                <td>

                                    <?php if($isOnSale): ?>
                                        <p>已上架</p>
                                    <?php elseif($isScheduledToSale): ?>
                                        <p>未上架</p>
                                    <?php else: ?>
                                        <p>已下架</p>
                                    <?php endif; ?>

                                </td>
                                <td>
                                    <div class="operate">
                                        
                                        <a href=<?php echo e(route('BannerRevise', [$item->id])); ?>

                                            class="border border-0 button-edit">編輯</a>

                                        

                                        <?php if($isOnSale): ?>
                                            <button class="border button-down" type="button"
                                                data-key=<?php echo e(route('Updatebanner_down', [$item->id])); ?>>下架</button>
                                        <?php elseif($isScheduledToSale): ?>
                                            <button data-key=<?php echo e(route('Updatebanner_down', [$item->id])); ?>

                                                class="border button-down" type="button">下架</button>
                                        <?php else: ?>
                                            <button class="border button-delete "
                                                data-key=<?php echo e(route('destorybanner', [$item->id])); ?>

                                                type="button">刪除</button>
                                        <?php endif; ?>




                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </tbody>
                </table>
            </div>
        </form>
        <form id="delete-form" action="" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>

        </form>

        <div class="prompt-box-down">
            <div class="prompt">
                <p class="size14">確定要下架嗎?</p>
                <div>
                    <input class="border confirm confirm-down" type="button" value="確認">
                    <input class="border cancel cancel-down" type="button" value="取消">
                </div>
            </div>
        </div>
        <div class="prompt-box-delete">
            <div class="prompt">
                <p class="size14">確定要刪除嗎?</p>
                <div>
                    <input class="border confirm confirm-delete" type="button" value="確認">
                    <input class="border cancel cancel-delete" type="button" value="取消">
                </div>
            </div>
        </div>
    </div>
    <!-- 以上分割 -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/banner.js']); ?>
    <script></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.seagate-templete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/github/new_sea/resources/views/seageat/Banner.blade.php ENDPATH**/ ?>