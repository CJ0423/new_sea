<?php $__env->startSection('title'); ?>
後端管理-建立通路
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/css/recommendestablish.scss']); ?>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('cut'); ?>
      <!-- 以下分割 -->
   <!-- 以下分割 -->
   <div class="size16">建立通路1</div>
   <div class="border border-0 card">
     <div class="frame-2">
       <div class="size12">推薦通路資訊</div>
     </div>
     <div class="frame-3">
       <div class="frame-4">

         <form action=<?php echo e(route("newRecommend")); ?> method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
           <div class="input">
             <div class="base-wrapper">
               <div class="base">
                 <div class="frame-5">
                   <div class="label">Logo上傳</div>
                   <div class="frame-6">
                     <div class="text-wrapper-5">必填</div>
                   </div>
                 </div>
                 <div class="input-field">
                     <label for="logo" class="border logo-label">選擇檔案</label>
                     <input type="file" name="logo_url" id="logo" class="logo-input" accept="image/png, image/jpeg, image/gif">
                 </div>
               </div>
             </div>
           </div>
           <div class="input">
             <div class="base-wrapper">
               <div class="base">
                 <div class="frame-5">
                   <div class="label">推薦通路名稱</div>
                   <div class="frame-6">
                     <div class="text-wrapper-5">必填</div>
                   </div>
                 </div>
                 <div class="input-field">
                   <input name="logo_name" type="text" class="border">
                 </div>
               </div>
             </div>
           </div>
           <div class="input">
             <div class="base-wrapper">
               <div class="base">
                 <div class="frame-5">
                   <div class="label">推薦通路連結</div>
                   <div class="frame-6">
                     <div class="text-wrapper-5">必填</div>
                   </div>
                 </div>
                 <div class="input-field">
                   <input name="logo_link" type="text" class="border">
                 </div>
               </div>
             </div>
           </div>

           <div class="frame-7">
               <button class="border button-3"><div class="text-5">捨棄修改</div></button>
             <button class="border-0 button-2"><div class="text-4">儲存</div></button>
           </div>
         </form>
       </div>
     </div>
   </div>
      <!-- 以上分割 -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.seagate-templete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/github/new_sea/resources/views/seageat/RecommendEstablish.blade.php ENDPATH**/ ?>