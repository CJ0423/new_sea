<?php $__env->startSection('title'); ?>
    後端管理-活動列表
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/activity.scss']); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('cut'); ?>
    <!-- 以下分割 -->
    <div class="size16">活動列表</div>
    <div class="border border-0 card">

        <!-- 提示訊息 -->
        <!-- <div class="prompt-box-down">
                                                                                             <div class="prompt">
                                                                                               <p class="size14">確定要下架嗎?</p>
                                                                                               <div>
                                                                                                 <input class="border confirm" type="button" value="確認">
                                                                                                 <input class="border cancel" type="button" value="取消">
                                                                                               </div>
                                                                                             </div>
                                                                                           </div> -->

        <div class="frame-2">
            <div class="size12">活動資訊</div>
            <div>
                <a href=<?php echo e(route('ActivityEstablish')); ?> class="button-establish">
                    <img class="icon-outline-plus" src=<?php echo e(asset('img/icon-outline-plus-22.svg')); ?>>
                    <div class="text-2">建立活動</div>
                </a>
                <a href=<?php echo e(route('ChosePattern')); ?> class="button-establish choose">
                    <img class="icon-outline-plus" src=<?php echo e(asset('img/icon-outline-plus-22.svg')); ?>>
                    <div class="text-2">選擇版型</div>
                </a>
            </div>
        </div>
        <form action="" method="post">
            <div class="frame-3">
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">活動編號</th>
                            <th scope="col">活動縮圖</th>
                            <th scope="col">主標題</th>
                            <th scope="col">版型編號</th>
                            <th scope="col">狀態</th>
                            <th scope="col">操作</th>
                        </tr>
                    </thead>
                    <tbody>
                        
                        <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="border-bottom">
                                <th scope="row"><?php echo e($index + 1); ?></th>
                                <td><img style="max-width:100px; max-height: 100px;"
                                        src=<?php echo e(asset('storage/' . $item->img_pc_url)); ?> alt=""></td>
                                <td><?php echo e($item->title); ?></td>
                                <td>

                                    <?php $__currentLoopData = $uniquePatterns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($items->activity_id == $item->id): ?>
                                            <a href="<?php echo e(route('store_patternShow', ['id' => $items->id, 'pattern' => 'block' . $items->whitch_pattern])); ?>"
                                                class="version-id">
                                                <?php echo e($items->whitch_pattern); ?>

                                            </a>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                    
                                    
                                </td>
                                <td>

                                    <?php $__currentLoopData = $uniquePatterns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        
                                        <?php if($item2->activity_id == $item->id): ?>
                                            <div> <?php echo e($item2->status); ?></div>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                </td>
                                <td>
                                    <div class="operate">
                                        <a id="<?php echo e($item->id); ?>" href=<?php echo e(route('ActivityRevise', $item->id)); ?>

                                            class="border border-0 button-edit">編輯</a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>


        </form>
    </div>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
        var trElements = document.querySelectorAll("tr");
        var trCount = trElements.length;

        var choose = document.querySelector('.choose') //選擇版型
        if(trCount >= 5){
            choose.style = "pointer-events:auto"
        }
    });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.seagate-templete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/github/new_sea/resources/views/seageat/Activity.blade.php ENDPATH**/ ?>