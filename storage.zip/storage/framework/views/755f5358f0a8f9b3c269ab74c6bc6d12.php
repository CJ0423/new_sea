<?php $__env->startSection('title'); ?>
後端管理-編輯選單
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/css/editmenu.scss']); ?>
<?php $__env->stopSection(); ?>




<?php $__env->startSection('cut'); ?>
<div class="size16">修改選單</div>
<div class="border border-0 card">
    <div class="frame-2">
        <div class="size12">選單資訊</div>
    </div>
    <div class="frame-3">
        <div class="frame-4">


            <form action=<?php echo e(route('updateMenu', ['id'=>$menu[0]->id])); ?> method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?>
                <div class="input">
                    <div class="base-wrapper">
                        <div class="base">
                            <div class="frame-5">
                                <div class="label">主選單名稱</div>
                                <div class="frame-6">
                                    <div class="text-wrapper-5">必填</div>
                                </div>
                            </div>
                            <div class="input-field">
                                <input  name="menu_name" type="text" class="border" value="<?php echo e($menu[0]->menu_name); ?>">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="input">
                    <div class="base-wrapper">
                        <div class="base">
                            <div class="frame-5">
                                <div class="label">主選單連結</div>
                                <div class="frame-6">
                                    <div class="text-wrapper-5">必填</div>
                                </div>
                            </div>
                            <div class="input-field">
                                <input name="menu_link" type="text" class="border" value="<?php echo e($menu[0]->menu_link); ?>">
                            </div>
                        </div>
                    </div>
                </div>
                <?php for($i=0;$i<4;$i++): ?>
                <hr>
                <div class="input">
                  <div class="base-wrapper">
                    <div class="base">
                      <div class="frame-5">
                        <div class="label">子選單名稱</div>
                      </div>
                      <div class="input-field">
                        <?php if($i<count($child)): ?>
                        <input name="child_menu_id<?php echo e($i); ?>" type="hidden" class="border" value="<?php echo e($child[$i]->id); ?>">
                        <input name="child_menu<?php echo e($i); ?>" type="text" class="border" value="<?php echo e($child[$i]->menu_name); ?>">
                        <?php else: ?>
                        <input name="child_menu_id<?php echo e($i); ?>" type="hidden" class="border" value="insert">
                        <input name="child_menu_new<?php echo e($i); ?>" type="text" class="border">
                        <?php endif; ?>

                      </div>
                    </div>
                  </div>
                </div>
                <div class="input">
                  <div class="base-wrapper">
                    <div class="base">
                      <div class="frame-5">
                        <div class="label">子選單連結</div>
                      </div>
                      <div class="input-field">
                        <?php if($i<count($child)): ?>
                        <input name="menu_link<?php echo e($i); ?>" type="text" class="border"  value="<?php echo e($child[$i]->menu_link); ?>">
                        <?php else: ?>
                        <input name="menu_link_new<?php echo e($i); ?>" type="text" class="border">
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                </div>
                <?php endfor; ?>

                <div class="frame-7">
                    <button class="border-0 button-2">
                        <div class="text-4">儲存</div>
                    </button>
                    <button class="border button-3">
                        <div class="text-5">捨棄</div>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.seagate-templete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/github/new_sea/resources/views/seageat/FrontPageEditMenu.blade.php ENDPATH**/ ?>