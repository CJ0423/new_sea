<?php $__env->startSection('title'); ?>
    後端管理-推薦通路管理
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/recommend.scss']); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('cut'); ?>
    <!-- 以下分割 -->
    <div class="size16">推薦通路管理</div>
    <div class="border border-0 card">

        <!-- 提示訊息 -->
        <!-- <div class="prompt-box-down">
              <div class="prompt">
                <p class="size14">確定要下架嗎?</p>
                <div>
                  <input class="border confirm" type="button" value="確認">
                  <input class="border cancel" type="button" value="取消">
                </div>
              </div>
            </div> -->

        <div class="frame-2">
            <div class="size12">推薦通路列表</div>
            <div>
                <a href=<?php echo e(route('RecommendEstablish')); ?> class="button-establish">


                    <img class="icon-outline-plus" src=<?php echo e(asset('img/icon-outline-plus-22.svg')); ?> />
                    <div class="text-2"> 建立通路</div>
                </a>
            </div>
        </div>




        <form id="delete-form" method="post">
            <?php echo method_field('DELETE'); ?>
            <?php echo csrf_field(); ?>
            <div class="frame-3">
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">編號</th>
                            <th scope="col">推薦通路Logo</th>
                            <th scope="col">推薦通路連結</th>
                            <th scope="col">操作</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $recommendData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="border-bottom">
                                <th scope="row"><?php echo e($index + 1); ?></th>
                                <td><img src='<?php echo e(asset('storage/' . $item->logo_url)); ?>'alt=""></td>
                                <td><?php echo e($item->logo_link); ?></td>
                                <td>
                                    <div class="operate">
                                        <a href=" <?php echo e(route('RecommendRevise', ['id' => $item->id])); ?>"
                                            class="border border-0 button-edit">編輯</a>
                                        <input data-key="<?php echo e(route('destoryRecommend', ['id' => $item->id])); ?>" type="button"
                                            class="border button-delete" value="刪除">


                                        
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>
        </form>
        <div class="prompt-box-down">
            <div class="prompt">
                <p class="size14">確定要捨棄嗎?</p>
                <div>
                    <input class="border confirm" type="button" value="確認">
                    <input class="border cancel" type="button" value="取消">
                </div>
            </div>
        </div>
    </div>
    <!-- 以上分割 -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src=<?php echo e(asset('./thedatepicker-master/dist/the-datepicker.js')); ?>></script>
    <script src=<?php echo e(asset('./thedatepicker-master/dist/dataPicker.js')); ?>></script>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/recommend.js']); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.seagate-templete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/github/new_sea/resources/views/seageat/Recommend.blade.php ENDPATH**/ ?>