<?php $__env->startSection('title'); ?>
    A-2
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/front/a2.scss']); ?>
    <style>
        /* @media (max-width:767px) {
                                                .a1-3 {
                                                    background-image: url("<?php echo e(asset('img/mainImg/a1/3-3.png')); ?>") !important;
                                                }

                                                .a1-4 {
                                                    background-image: url("<?php echo e(asset('img/mainImg/a1/4-4.png')); ?>") !important;
                                                }
                                            } */
        <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


            .a1-<?php echo e($index + 1); ?> {
                background-image: url('<?php echo e(asset('storage/' . $item->img_pc_url)); ?>');
            }

            @media (max-width:767px) {
                .a1-<?php echo e($index + 1); ?> {
                    background-image: url('<?php echo e(asset('storage/' . $item->img_pad_url)); ?>');
                }
            }
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('version'); ?>
    <div class="container-pc container-pc-a2">
        <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div data-aos="custom-animation-up" class="a<?php echo e($index + 1); ?><?php echo e($item->img_size_pad); ?> ">
                <figure class="main-img a1-<?php echo e($index); ?>">
                    <figcaption>
                        <h2><?php echo e($item->title); ?></h2>
                        <h3><?php echo e($item->subtitle); ?></h3>
                        <a href="<?php echo e($item->button_link); ?>" class="buy-now-button"><?php echo e($item->button_name); ?></a>
                    </figcaption>
                </figure>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div style="clear: both"></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/github/new_sea/resources/views/front/A2.blade.php ENDPATH**/ ?>